from django.apps import AppConfig


class XplorAppConfig(AppConfig):
    name = 'xplor_app'
