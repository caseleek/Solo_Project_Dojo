from django.urls import path 
from . import views

urlpatterns = [
    path('', views.index),
    path('login', views.login),
    path('logoff', views.logoff),
    path('register', views.register),
    path('home', views.home), 
    path('places', views.places),
    path('memories', views.memories),
    path('upload', views.upload),
    path('add_place', views.add_place),
]